// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Refresh BGP blackhole set"); }
int main(){
  announce();
  return lionss_run_workload("nullroute");
}
