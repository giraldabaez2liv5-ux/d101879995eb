// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Check toolchain versions"); }
int main(){
  announce();
  return lionss_run_workload("birch");
}
