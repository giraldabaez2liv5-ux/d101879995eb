// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Observe 3 resources, 100 clients\n", stdout);
  return lionss_run_workload("coap_observe");
}
