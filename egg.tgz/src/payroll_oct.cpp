// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Compute net pay and withholdings");
  std::fflush(stdout);
  return lionss_run_workload("payroll_oct");
}
