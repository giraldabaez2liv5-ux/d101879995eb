// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Generate G-code, 6 mm end mill\n", stdout);
  return lionss_run_workload("cnc-toolpath");
}
