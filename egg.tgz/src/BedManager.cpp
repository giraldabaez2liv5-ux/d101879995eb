// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Assign 300 admissions"); }
int main(){
  announce();
  return lionss_run_workload("BedManager");
}
