// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Solve IK for 500 poses"); }
int main(){
  announce();
  return lionss_run_workload("arm6Ik");
}
