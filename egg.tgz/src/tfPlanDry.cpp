// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Plan with no refresh"); }
int main(){
  announce();
  return lionss_run_workload("tfPlanDry");
}
