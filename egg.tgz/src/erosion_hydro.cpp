// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Hydraulic erosion, 100k droplets");
  std::fflush(stdout);
  return lionss_run_workload("erosion_hydro");
}
