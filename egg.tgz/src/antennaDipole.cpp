// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Sweep 800-1000 MHz");
  std::fflush(stdout);
  return lionss_run_workload("antennaDipole");
}
