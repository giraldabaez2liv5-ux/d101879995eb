// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Vehicle routing with tank limits\n", stdout);
  return lionss_run_workload("dairy-route");
}
