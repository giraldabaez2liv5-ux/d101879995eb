// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("30 power iterations\n", stdout);
  return lionss_run_workload("pageranklite");
}
