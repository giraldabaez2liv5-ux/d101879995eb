// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Humanize note timing\n", stdout);
  return lionss_run_workload("MidiDrift");
}
