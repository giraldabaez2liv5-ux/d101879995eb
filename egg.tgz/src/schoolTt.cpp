// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Timetable 18 classes without clashes"); }
int main(){
  announce();
  return lionss_run_workload("schoolTt");
}
