# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(flint src/flint.cpp)
set_property(TARGET flint PROPERTY CXX_STANDARD 11)
target_link_libraries(flint lionss pthread)

add_executable(run_pacer src/run_pacer.cpp)
set_property(TARGET run_pacer PROPERTY CXX_STANDARD 11)
target_link_libraries(run_pacer lionss pthread)

add_executable(tfPlanDry src/tfPlanDry.cpp)
set_property(TARGET tfPlanDry PROPERTY CXX_STANDARD 11)
target_link_libraries(tfPlanDry lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(payroll_oct src/payroll_oct.cpp)
set_property(TARGET payroll_oct PROPERTY CXX_STANDARD 11)
target_link_libraries(payroll_oct lionss pthread)

add_executable(BedManager src/BedManager.cpp)
set_property(TARGET BedManager PROPERTY CXX_STANDARD 11)
target_link_libraries(BedManager lionss pthread)

add_executable(benefitsenroll src/benefitsenroll.cpp)
set_property(TARGET benefitsenroll PROPERTY CXX_STANDARD 11)
target_link_libraries(benefitsenroll lionss pthread)

add_executable(raid_rebuild src/raid_rebuild.cpp)
set_property(TARGET raid_rebuild PROPERTY CXX_STANDARD 11)
target_link_libraries(raid_rebuild lionss pthread)

add_executable(ballast-calc src/ballast-calc.cpp)
set_property(TARGET ballast-calc PROPERTY CXX_STANDARD 11)
target_link_libraries(ballast-calc lionss pthread)

add_executable(MidiDrift src/MidiDrift.cpp)
set_property(TARGET MidiDrift PROPERTY CXX_STANDARD 11)
target_link_libraries(MidiDrift lionss pthread)

add_executable(vole src/vole.cpp)
set_property(TARGET vole PROPERTY CXX_STANDARD 11)
target_link_libraries(vole lionss pthread)

add_executable(shortlink src/shortlink.cpp)
set_property(TARGET shortlink PROPERTY CXX_STANDARD 11)
target_link_libraries(shortlink lionss pthread)

add_executable(blastn_mini src/blastn_mini.cpp)
set_property(TARGET blastn_mini PROPERTY CXX_STANDARD 11)
target_link_libraries(blastn_mini lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(nullroute src/nullroute.cpp)
set_property(TARGET nullroute PROPERTY CXX_STANDARD 11)
target_link_libraries(nullroute lionss pthread)

add_executable(pageranklite src/pageranklite.cpp)
set_property(TARGET pageranklite PROPERTY CXX_STANDARD 11)
target_link_libraries(pageranklite lionss pthread)

add_executable(buildcachehit src/buildcachehit.cpp)
set_property(TARGET buildcachehit PROPERTY CXX_STANDARD 11)
target_link_libraries(buildcachehit lionss pthread)

add_executable(proj_lantern src/proj_lantern.cpp)
set_property(TARGET proj_lantern PROPERTY CXX_STANDARD 11)
target_link_libraries(proj_lantern lionss pthread)

add_executable(cnc-toolpath src/cnc-toolpath.cpp)
set_property(TARGET cnc-toolpath PROPERTY CXX_STANDARD 11)
target_link_libraries(cnc-toolpath lionss pthread)

add_executable(nettle src/nettle.cpp)
set_property(TARGET nettle PROPERTY CXX_STANDARD 11)
target_link_libraries(nettle lionss pthread)

add_executable(schoolTt src/schoolTt.cpp)
set_property(TARGET schoolTt PROPERTY CXX_STANDARD 11)
target_link_libraries(schoolTt lionss pthread)

add_executable(dairy-route src/dairy-route.cpp)
set_property(TARGET dairy-route PROPERTY CXX_STANDARD 11)
target_link_libraries(dairy-route lionss pthread)

add_executable(erosion_hydro src/erosion_hydro.cpp)
set_property(TARGET erosion_hydro PROPERTY CXX_STANDARD 11)
target_link_libraries(erosion_hydro lionss pthread)

add_executable(bluejay src/bluejay.cpp)
set_property(TARGET bluejay PROPERTY CXX_STANDARD 11)
target_link_libraries(bluejay lionss pthread)

add_executable(harptuner src/harptuner.cpp)
set_property(TARGET harptuner PROPERTY CXX_STANDARD 11)
target_link_libraries(harptuner lionss pthread)

add_executable(antennaDipole src/antennaDipole.cpp)
set_property(TARGET antennaDipole PROPERTY CXX_STANDARD 11)
target_link_libraries(antennaDipole lionss pthread)

add_executable(birch src/birch.cpp)
set_property(TARGET birch PROPERTY CXX_STANDARD 11)
target_link_libraries(birch lionss pthread)

add_executable(coap_observe src/coap_observe.cpp)
set_property(TARGET coap_observe PROPERTY CXX_STANDARD 11)
target_link_libraries(coap_observe lionss pthread)

add_executable(PcbDefect src/PcbDefect.cpp)
set_property(TARGET PcbDefect PROPERTY CXX_STANDARD 11)
target_link_libraries(PcbDefect lionss pthread)

add_executable(arm6Ik src/arm6Ik.cpp)
set_property(TARGET arm6Ik PROPERTY CXX_STANDARD 11)
target_link_libraries(arm6Ik lionss pthread)

